import { useState } from 'react';


const CustomToken = () => {
    const [select, setSelect] = useState('Hold Tokens');
    return (
    <>
    <h1 className='text-6xl text-black'>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Debitis reiciendis recusandae perferendis ea cumque illum et sed odio a, dolorem, non corporis animi. Cum doloremque vero dolores soluta incidunt voluptatum.
    </h1>
    </>
    )
}

export default CustomToken
